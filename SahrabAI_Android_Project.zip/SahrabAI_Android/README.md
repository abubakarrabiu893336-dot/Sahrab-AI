# Sahrab AI Android App
Professional Android WebView wrapper for https://sahrab-ai.ai.studio

Features: branded splash/loading screen, full-screen experience, Android Back navigation, JavaScript/local storage support, portrait mode.

Open in Android Studio, sync Gradle, then Build > Build APK(s).
Application ID: com.sahrab.ai
